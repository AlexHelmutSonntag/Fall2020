package car.utils;

public enum Color {
    RED,
    GREEN,
    BLUE
}